package core.queue;

import core.exceptions.InternalServerErrorException;
import core.services.chimeevents.ChimeEventService;
import core.services.chimeevents.ChimeEventServiceFactory;
import core.utils.ChimeEnums;
import core.utils.Enums;
import org.json.JSONException;
import org.json.JSONObject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service("defaultQueueMessageHandler")
public class DefaultQueueMessageHandler implements QueueMessageHandler {
    private static final Logger logger = LoggerFactory.getLogger(DefaultQueueMessageHandler.class);

    @Autowired
    private ChimeEventServiceFactory chimeEventServiceFactory;


    @Override
    public void handleQueueMessage(String queueMessage, String messageId) {
        logger.debug("handleQueueMessage started for messageId: {}", messageId);
        try {
            JSONObject messageJSON = new JSONObject(queueMessage);
            String eventSource = fetchEventSource(messageJSON);
            ChimeEventService chimeEventService = chimeEventServiceFactory.getChimeEventService(eventSource);
            chimeEventService.processEvents(messageJSON, eventSource);
        } catch (JSONException e) {
            logger.error("Failed to parse the message {}", queueMessage, e);
            throw new InternalServerErrorException(Enums.ErrorCode.JSON_PARSING_ERROR, Enums.ErrorCode.JSON_PARSING_ERROR.getName(),e);
        }
        logger.debug("handleQueueMessage Completed for messageId: {}", messageId);
    }

    private String fetchEventSource(JSONObject messageJSON) {
        String eventSource = null;
        try {
            eventSource = messageJSON.getString("source");
            switch (eventSource) {
                case "aws.chime":
                    eventSource = ChimeEnums.EventSource.ChimeServer.getName();
                    break;
            }
        } catch (JSONException e) {
            logger.error("Failed to parse the message {}", messageJSON, e);
            throw new InternalServerErrorException(Enums.ErrorCode.JSON_PARSING_ERROR, Enums.ErrorCode.JSON_PARSING_ERROR.getName(),e);
        }
        logger.debug("eventSource from fetchEventSource method is: {}", eventSource);
        return eventSource;
    }

}
