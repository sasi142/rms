package core.services;

import core.entities.RmsMessage;

public interface InfoService {
	public void sendInfo(RmsMessage message);
	public void createTrackingEvent(RmsMessage message);
}
