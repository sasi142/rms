package core.services.chimeevents;

import org.json.JSONObject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

@Service("chimeRecordingEventServiceImpl")
public class ChimeRecordingEventServiceImpl implements ChimeEventService {
	final static Logger logger = LoggerFactory.getLogger(ChimeRecordingEventServiceImpl.class);


	@Override
	public void processEvents(JSONObject queueMessageJson, String eventSource) {

	}
}
