package core.services.chimeevents;

import org.json.JSONObject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

@Service("chimeMediaConvertEventServiceImpl")
public class ChimeMediaConvertEventServiceImpl implements ChimeEventService {
	final static Logger logger = LoggerFactory.getLogger(ChimeMediaConvertEventServiceImpl.class);


	@Override
	public void processEvents(JSONObject queueMessageJson, String eventSource) {

	}
}
