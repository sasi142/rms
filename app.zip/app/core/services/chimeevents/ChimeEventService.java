package core.services.chimeevents;

import org.json.JSONObject;

public interface ChimeEventService {
    void processEvents(JSONObject queueMessageJson, String eventSource);
}