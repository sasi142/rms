package core.services.chimeevents;

import core.daos.MeetingInfoDao;
import core.entities.ChimeMeetingEvent;
import core.exceptions.InternalServerErrorException;
import core.utils.ChimeEnums;
import core.utils.Enums;
import core.utils.ThreadContext;
import org.json.JSONException;
import org.json.JSONObject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.util.StringUtils;

@Service("chimeMeetingEventService")
public class ChimeMeetingEventServiceImpl implements ChimeEventService {
    final static Logger logger = LoggerFactory.getLogger(ChimeMeetingEventServiceImpl.class);

    @Autowired
    private ChimeEventTrackingService chimeEventTrackingService;

    @Autowired
    private MeetingInfoDao meetingInfoDao;

    @Override
    public void processEvents(JSONObject queueMessageJson, String eventSource) {
        ChimeMeetingEvent chimeMeetingEvent = frameChimeMeeting(queueMessageJson, eventSource);
        if (!StringUtils.isEmpty(chimeMeetingEvent.getEventId())) {
            chimeEventTrackingService.saveChimeMeetingEvent(chimeMeetingEvent);

            if (ChimeEnums.EventType.ChimeMeetingStarted.getId().equals(chimeMeetingEvent.getEventType().byteValue())) {
                meetingInfoDao.updateMeetingStatus(chimeMeetingEvent.getMeetingId(), ChimeEnums.EventType.ChimeMeetingStarted.getId().byteValue(), null);
            } else if (ChimeEnums.EventType.ChimeMeetingEnded.getId().equals(chimeMeetingEvent.getEventType().byteValue())) {
                meetingInfoDao.updateMeetingStatus(chimeMeetingEvent.getMeetingId(), ChimeEnums.EventType.ChimeMeetingEnded.getId().byteValue(), null);
            } else if (ChimeEnums.EventType.ChimeAttendeeJoined.getId().equals(chimeMeetingEvent.getEventType().byteValue())) {
                meetingInfoDao.updateMeetingStatus(chimeMeetingEvent.getMeetingId(), ChimeEnums.EventType.ChimeAttendeeJoined.getId().byteValue(), null);
            } else if (ChimeEnums.EventType.ChimeAttendeeLeft.getId().equals(chimeMeetingEvent.getEventType().byteValue())) {
                meetingInfoDao.updateMeetingStatus(chimeMeetingEvent.getMeetingId(), ChimeEnums.EventType.ChimeAttendeeLeft.getId().byteValue(), null);
            }
        }
    }

    private ChimeMeetingEvent frameChimeMeeting(JSONObject queueMessageJson, String eventSource) {
        ChimeMeetingEvent chimeMeetingEvent = new ChimeMeetingEvent();
        try {
            if ("Chime Meeting State Change".equalsIgnoreCase(queueMessageJson.getString("detail-type"))) {
                String eventId = queueMessageJson.getString("id");
                JSONObject detailJson = queueMessageJson.getJSONObject("detail");
                Integer meetingId = detailJson.getInt("externalMeetingId");
                String eventType = detailJson.getString("eventType");
                Long eventTime = detailJson.getLong("timestamp");
                String data = detailJson.toString();

                if (!StringUtils.isEmpty(eventId)) {
                    chimeMeetingEvent.setEventId(eventId);
                }

                if (meetingId != null) {
                    chimeMeetingEvent.setMeetingId(meetingId);
                }

                ChimeEnums.EventType eventTypeEnum = ChimeEnums.EventType.getEnum(eventType);
                if (eventTypeEnum != null) {
                    chimeMeetingEvent.setEventType(eventTypeEnum.getId().byteValue());
                }

                if (eventTime != null) {
                    chimeMeetingEvent.setEventTime(eventTime);
                }

                if (!StringUtils.isEmpty(eventId)) {
                    chimeMeetingEvent.setData(data);
                }

                ChimeEnums.EventSource eventSourceEnum = ChimeEnums.EventSource.getEnum(eventSource);
                if (eventSourceEnum != null) {
                    chimeMeetingEvent.setEventSource(eventSourceEnum.getId().byteValue());
                }
                chimeMeetingEvent.setCreatedDate(System.currentTimeMillis());
                chimeMeetingEvent.setActive(true);
            }
        } catch (JSONException e) {
            logger.error("Failed to parse the message {}", queueMessageJson, e);
            throw new InternalServerErrorException(Enums.ErrorCode.JSON_PARSING_ERROR, Enums.ErrorCode.JSON_PARSING_ERROR.getName(),e);
        }
        return chimeMeetingEvent;
    }

}
