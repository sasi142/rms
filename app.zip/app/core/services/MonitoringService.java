package core.services;

import core.entities.ActorMonitor;

public interface MonitoringService {
	public ActorMonitor getActorMonitor(Boolean actors, Boolean details);
}
