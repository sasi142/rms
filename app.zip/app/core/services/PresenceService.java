package core.services;

import core.entities.Presence;

public interface PresenceService {
	public void sendPresenceInfoToContact(Integer Id);
	public Presence getPresence(Integer Id, Boolean checkClosed);	
	public Presence getGroupPresence(Integer id);
}
