package core.services;

public interface PubSubService {
	public void subscribe();
}
