package core.services;

import core.entities.ChatMessage;
import messages.UserConnection;

public interface One2OneChatMessageService {
	public void sendMessage(UserConnection connection, ChatMessage message);
}
