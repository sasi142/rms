package core.services;

import core.entities.ApiRequest;

public interface CommonService {
	public void createApiRequest(ApiRequest apiRequest);
}
