package core.services;

import core.entities.VideoSignallingMessage;
import messages.UserConnection;

public interface VideoSignallingService {
	public void handleMessage(UserConnection connection, VideoSignallingMessage videoSignallingMessage);
}
