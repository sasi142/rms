package core.exceptions;

import core.utils.Enums.ErrorCode;

public class ContactOfflineException extends ApplicationException {
	private static final long	serialVersionUID	= 1L;

	public ContactOfflineException(ErrorCode code, String message) {
		super(code, message);
	}

	public ContactOfflineException(ErrorCode code, String message, Exception ex) {
		super(code, message, ex);
	}

}
