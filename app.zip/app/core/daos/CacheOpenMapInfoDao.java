package core.daos;


public interface CacheOpenMapInfoDao {
	public void create(Integer userId);

	public void remove(Integer userId);
}
