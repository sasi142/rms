package core.daos;

import java.util.Map;

public interface CacheInstanceInfoDao {
	public void saveInstanceInfo(String instanceId, String time);
	public void removeInstanceInfo(String instanceId);
	public Map<String, String> getAllInstanceInfo();	
}
