package core.daos;

import core.entities.ChimeMeetingEvent;
import core.entities.MeetingEvent;

import java.util.List;


public interface MeetingEventDao extends JpaDao<MeetingEvent>{
}
