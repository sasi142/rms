package core.daos;

public class BroadcastRecipientDao {

}
