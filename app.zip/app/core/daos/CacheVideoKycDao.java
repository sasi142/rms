package core.daos;

import com.fasterxml.jackson.databind.node.ObjectNode;

public interface CacheVideoKycDao {

    ObjectNode get(Integer kycId);

    void put(Integer kycId, ObjectNode kyc);
}
