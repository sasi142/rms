package core.daos;

import core.entities.Meeting;
import core.entities.MeetingAttendee;

public interface MeetingAttendeeDao extends JpaDao<MeetingAttendee>{

	public void updateMeetingAttendeeStatus(Integer meetingId, Byte meetingStatus);
}
