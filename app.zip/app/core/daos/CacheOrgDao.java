package core.daos;

import com.fasterxml.jackson.databind.JsonNode;

public interface CacheOrgDao {
	public JsonNode find(Integer orgId);
}
