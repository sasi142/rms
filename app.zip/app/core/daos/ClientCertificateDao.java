package core.daos;

import java.util.List;

import core.entities.ClientCertificate;

public interface ClientCertificateDao extends JpaDao<ClientCertificate> {
	public List<ClientCertificate> getClientCertificates();
}
