package core.daos;
import core.entities.UserEvent;
public interface UserEventDao extends JpaDao<UserEvent> {

}
