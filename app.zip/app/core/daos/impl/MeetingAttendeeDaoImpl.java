package core.daos.impl;

import core.daos.MeetingAttendeeDao;
import core.daos.MeetingInfoDao;
import core.entities.Meeting;
import core.entities.MeetingAttendee;
import core.exceptions.InternalServerErrorException;
import core.utils.Enums.ErrorCode;
import core.utils.Enums.VideoCallStatus;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import javax.persistence.*;

@Repository
public class MeetingAttendeeDaoImpl extends AbstractJpaDAO<MeetingAttendee> implements MeetingAttendeeDao{
	final Logger logger = LoggerFactory.getLogger(MeetingAttendeeDaoImpl.class);

	@PersistenceContext
	protected  EntityManager entityManager;

	public MeetingAttendeeDaoImpl() {
		super();
		setClazz(MeetingAttendee.class);
	}

	@Override
	public void updateMeetingAttendeeStatus(Integer meetingId, Byte meetingRating) {
		logger.debug("updateMeetingAttendeeStatus started.");
		try {
			Query updateMeetingRating = entityManager.createNamedQuery("updateMeetingRating");
			updateMeetingRating.setParameter("meetingId", meetingId);
			updateMeetingRating.setParameter("meetingRating", meetingRating);
			updateMeetingRating.executeUpdate();

		}catch (Exception e) {
			throw new InternalServerErrorException(ErrorCode.Internal_Server_Error,
					"Failed to update MeetingAttendeeStatus "+ e);
		}
		logger.debug("updateMeetingAttendeeStatus ended.");
	}






	

	
} 