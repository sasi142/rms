package core.daos.impl;

import org.springframework.stereotype.Repository;

import core.daos.ApiRequestDao;
import core.entities.ApiRequest;

@Repository
public class ApiRequestDaoImpl extends AbstractJpaDAO<ApiRequest> implements ApiRequestDao {
	public ApiRequestDaoImpl() {
		super();
		setClazz(ApiRequest.class);
	}
}
