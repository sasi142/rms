package core.daos.impl;

public class BroadcastRecipientDaoImpl {

}
