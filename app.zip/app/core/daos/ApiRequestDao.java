package core.daos;

import core.entities.ApiRequest;

public interface ApiRequestDao extends JpaDao<ApiRequest> {

}
