package core.entities;

public class VideokycCall {
 
}
