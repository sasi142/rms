package core.entities;

import core.daos.JpaDao;

public interface MeetingEventDao extends JpaDao<MeetingEvent> {

}
